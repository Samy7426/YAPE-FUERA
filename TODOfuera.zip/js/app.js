/*$(document).ready(function () {

    const firebaseConfig = {
       apiKey: "AIzaSyCyyKD3dIC8QmNnmzhEluQVPOtLfo8XCSo",
       authDomain: "mascotaspet-79ed8.firebaseapp.com",
       projectId: "mascotaspet-79ed8",
       storageBucket: "mascotaspet-79ed8.appspot.com",
       messagingSenderId: "848480192367",
       appId: "1:848480192367:web:bb0a8d69ca2900badc4a9a"
     };
   

  
   const firebaseConfig = {
       apiKey: "AIzaSyDg-tQbojdCGcIHEM7VoJICnjM5IeNWg-Q",
       authDomain: "login-d05d0.firebaseapp.com",
       databaseURL: "https://login-d05d0-default-rtdb.firebaseio.com",
       projectId: "login-d05d0",
       storageBucket: "login-d05d0.appspot.com",
       messagingSenderId: "716815741869",
       appId: "1:716815741869:web:83594b65bb2f2fd3cea724"
     };
   
   
   
       // Initialize Firebase
       const app = firebase.initializeApp(firebaseConfig);
       console.log(app);
   
   
       //Registrar Usuario en Firebase
       $("#crear").click(function (e) {
           e.preventDefault(); //evitar que se recargue
           var regCorreo = $("#regCorreo").val();
           var regPass = $("#regPass").val();
   
           console.log(regCorreo, regPass);
   
           firebase.auth().createUserWithEmailAndPassword(regCorreo, regPass)
               .then((userCredential) => {
                   window.location.href = "index.html";
               })
               .catch((error) => {
                   var errorCode = error.code;
                   var errorMessage = error.message;
   
                   console.log(errorCode, errorMessage);
               });
       });
   
   
       //INCIAR SESION
       $("#inicio").click(function (e) {
           e.preventDefault(); //evitar que se recargue
           var correo2 = $("#iniCorreo").val();
           var contra2 = $("#iniPass").val();
   
           console.log(correo2, contra2);
   
           firebase.auth().signInWithEmailAndPassword(correo2, contra2)
               .then((userCredential) => {
                   window.location.href = "https://yape-te-educa.samymelgarejo.repl.co/";
               })
               .catch((error) => {
                   var errorCode = error.code;
                   var errorMessage = error.message;
                   console.log("ERROR - No carga", errorCode, errorMessage);
               });
       })
   
      // CERRAR SESION
       $("#cerrar").click(function () {
           firebase.auth().signOut().then(() => {
               window.location.href = "https://yapeee.katyvasquez.repl.co/";
           }).catch((error) => {
               // An error happened.
           });
       })
   
   });




*/





















   $(document).ready(function () {

    /*const firebaseConfig = {
       apiKey: "AIzaSyCyyKD3dIC8QmNnmzhEluQVPOtLfo8XCSo",
       authDomain: "mascotaspet-79ed8.firebaseapp.com",
       projectId: "mascotaspet-79ed8",
       storageBucket: "mascotaspet-79ed8.appspot.com",
       messagingSenderId: "848480192367",
       appId: "1:848480192367:web:bb0a8d69ca2900badc4a9a"
     };
   */

  
   const firebaseConfig = {
       apiKey: "AIzaSyDg-tQbojdCGcIHEM7VoJICnjM5IeNWg-Q",
       authDomain: "login-d05d0.firebaseapp.com",
       databaseURL: "https://login-d05d0-default-rtdb.firebaseio.com",
       projectId: "login-d05d0",
       storageBucket: "login-d05d0.appspot.com",
       messagingSenderId: "716815741869",
       appId: "1:716815741869:web:83594b65bb2f2fd3cea724"
     };
   
   
   
       // Initialize Firebase
       const app = firebase.initializeApp(firebaseConfig);
       console.log(app);
   
   
       //Registrar Usuario en Firebase
       $("#crear").click(function (e) {
           e.preventDefault(); //evitar que se recargue
           var regCorreo = $("#regCorreo").val();
           var regPass = $("#regPass").val();
   
           console.log(regCorreo, regPass);
   
           firebase.auth().createUserWithEmailAndPassword(regCorreo, regPass)
               .then((userCredential) => {
                   window.location.href = "index.html";
               })
               .catch((error) => {
                   var errorCode = error.code;
                   var errorMessage = error.message;
   
                   console.log(errorCode, errorMessage);
               });
       });
   
   
       //INCIAR SESION
       $("#inicio").click(function (e) {
           e.preventDefault(); //evitar que se recargue
           var correo2 = $("#iniCorreo").val();
           var contra2 = $("#iniPass").val();
   
           console.log(correo2, contra2);
   
           firebase.auth().signInWithEmailAndPassword(correo2, contra2)
               .then((userCredential) => {
                   window.location.href = "https://tododentro--samybenites16.repl.co/Inicio.html";
               })
               .catch((error) => {
                   var errorCode = error.code;
                   var errorMessage = error.message;
                   console.log("ERROR - No carga", errorCode, errorMessage);
               });
       })
   
       // CERRAR SESION
       $("#cerrar").click(function () {
           firebase.auth().signOut().then(() => {
               window.location.href = "https://replit.com/@SamyMelgarejo1/YAPEfuera#js/app.js";
           }).catch((error) => {
               // An error happened.
           });
       })
   
   });